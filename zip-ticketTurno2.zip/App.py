from flask import Flask, render_template, url_for, request, redirect, jsonify, send_file
from model.package_model.Usuario import Usuarios
from model.package_model.Formulario import Formulario
from fpdf import FPDF
import os
import qrcode
import matplotlib.pyplot as plt
import io
import base64
import pandas as pd


app = Flask(__name__)
app.secret_key = 'keykey'

HCAPTCHA_SECRET = 'ES_ef2fbcaf50b4434f9d9b9d05d4cd6ae3'

@app.route('/')
def index():
    return render_template('Index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.is_json:
            data = request.get_json()
            print(data, '\n\n\n')
            usuario = data.get('f_user')
            contrasena = data.get('f_pwd')
        else:
            usuario = request.form.get('f_user')
            contrasena = request.form.get('f_pwd')
        
        usuario_model = Usuarios()
        user = usuario_model.verificar_credenciales(usuario, contrasena)

        if user:
            return jsonify({'redirect': url_for('admin')})
        else:
            return jsonify({'message': 'Usuario o contraseña incorrectos'})

    return render_template('login.html')

@app.route('/logout')
def logout():
    return redirect(url_for('index'))

@app.route('/admin_logout')
def admin_logout():
    return redirect(url_for('login'))

@app.route('/admin')
def admin():
    formulario_model = Formulario()
    forms = formulario_model.obtener_formularios()
    return render_template('admin.html', forms=forms)

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/dashboard/data')
def dashboard_data():
    id_mun = request.args.get('id_mun')
    municipio = request.args.get('municipio')
    estado = request.args.get('estado')

    formulario_model = Formulario()
    if id_mun:
        forms = formulario_model.obtener_formularios_por_id_municipio(id_mun)
        title = f'Solicitudes para Municipio ID {id_mun}'
    elif municipio:
        forms = formulario_model.obtener_formularios_por_nombre_municipio(municipio)
        title = f'Solicitudes para Municipio {municipio}'
    elif estado == 'Todos':
        forms = formulario_model.obtener_formularios()
        title = 'Todas las Solicitudes'
    elif estado:
        forms = formulario_model.obtener_formularios_por_estado(estado)
        title = f'Solicitudes en Estado {estado}'
    else:
        forms = formulario_model.obtener_formularios()
        title = 'Todas las Solicitudes'

    # Convertir los formularios en un DataFrame de Pandas
    df = pd.DataFrame(forms, columns=['no_turno', 'curp', 'nombre', 'paterno', 'materno', 'telefono', 'celular', 'correo', 'id_nivel', 'id_mun', 'id_asunto', 'estado'])
    
    # Contar los estados
    estado_counts = df['estado'].value_counts()
    
    # Generar la gráfica
    plt.figure(figsize=(10, 6))
    if estado == 'Todos':
        colors = ['blue', 'green', 'red']
        estado_counts = df['estado'].value_counts()
    else:
        colors = ['red', 'blue', 'green']
        estado_counts = df[df['estado'] == estado]['municipio'].value_counts()
        
    estado_counts.plot(kind='bar', color=colors)
    plt.title(title)
    plt.xlabel('Estado')
    plt.ylabel('Cantidad')

    # Guardar la imagen en un buffer
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.getvalue()).decode('utf-8')
    buf.close()

    return jsonify({'image': 'data:image/png;base64,{}'.format(image_base64)})


@app.route('/generar_ticket', methods=['POST'])
def generar_ticket():
    if request.method == 'POST':
        return redirect(url_for('ticket', **request.form.to_dict()))

    return redirect(url_for('index'))

@app.route('/ticket')
def ticket():
    return render_template('Ticket.html', data=request.args.to_dict())

@app.route('/generar_pdf', methods=['POST'])
def generar_pdf():
    data = request.json
    pdf_dir = os.path.join(app.root_path, 'static', 'pdf')
    qr_dir = os.path.join(app.root_path, 'static', 'qr')
    if not os.path.exists(pdf_dir):
        os.makedirs(pdf_dir)
    if not os.path.exists(qr_dir):
        os.makedirs(qr_dir)
    
    existing_files = os.listdir(pdf_dir)
    for file in existing_files:
        if data['curp'] in file and data['asunto'] in file:
            pdf_filename = file
            pdf_url = url_for('static', filename=f'pdf/{pdf_filename}', _external=True)
            return jsonify({'success': True, 'pdf_url': pdf_url})
    
    no_turno = 1
    if existing_files:
        existing_numbers = [int(f.split('-')[0]) for f in existing_files if '-' in f]
        if existing_numbers:
            no_turno = max(existing_numbers) + 1

    pdf_filename = f"{no_turno}-{data['curp']}-{data['asunto']}.pdf"
    pdf_output = os.path.join(pdf_dir, pdf_filename)
    
    qr_content = f"CURP: {data['curp']}, No Turno: {no_turno}"
    qr_image = qrcode.make(qr_content)
    qr_filename = f"{no_turno}-{data['curp']}-{data['asunto']}.png"
    qr_output = os.path.join(qr_dir, qr_filename)
    qr_image.save(qr_output)
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(200, 10, txt="Ticket de Turno", ln=True, align='C')
    pdf.ln(10)
    pdf.cell(200, 10, txt=f"Nombre Completo: {data['nc']}", ln=True)
    pdf.cell(200, 10, txt=f"CURP: {data['curp']}", ln=True)
    pdf.cell(200, 10, txt=f"Nombre: {data['nombre']}", ln=True)
    pdf.cell(200, 10, txt=f"Apellido Paterno: {data['paterno']}", ln=True)
    pdf.cell(200, 10, txt=f"Apellido Materno: {data['materno']}", ln=True)
    pdf.cell(200, 10, txt=f"Teléfono: {data['telefono']}", ln=True)
    pdf.cell(200, 10, txt=f"Celular: {data['celular']}", ln=True)
    pdf.cell(200, 10, txt=f"Correo: {data['correo']}", ln=True)
    pdf.cell(200, 10, txt=f"Nivel: {data['nivel']}", ln=True)
    pdf.cell(200, 10, txt=f"Municipio: {data['municipio']}", ln=True)
    pdf.cell(200, 10, txt=f"Asunto: {data['asunto']}", ln=True)
    
    pdf.ln(10)
    pdf.image(qr_output, x = None, y = None, w = 50, h = 50)
    pdf.output(pdf_output)
    pdf_url = url_for('static', filename=f'pdf/{pdf_filename}', _external=True)

    return jsonify({'success': True, 'pdf_url': pdf_url})

if __name__ == '__main__':
    app.run(debug=True)