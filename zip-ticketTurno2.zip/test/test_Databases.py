import model.package_model.Database as Database

db = Database.Database()