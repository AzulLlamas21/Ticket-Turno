import ticketTurno.model.db as db

db = db.Database()